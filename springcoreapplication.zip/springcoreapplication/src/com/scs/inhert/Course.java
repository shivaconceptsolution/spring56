package com.scs.inhert;

public class Course {
   private int courseid;
   private String coursename;
   Student st;
   Course()
   {
	   
   }
   Course(int courseid,String coursename)
   {
	   super();
	   this.courseid=courseid;
	   this.coursename=coursename;
   }
   Course(int courseid,String coursename,Student st)
   {
	   super();
	   this.courseid=courseid;
	   this.coursename=coursename;
	   this.st=st;
   }
   public void display()
   {
	   System.out.println("Course id is "+courseid);
	   System.out.println("Course name is "+coursename);
	   st.display();
	   
   }
   
}
