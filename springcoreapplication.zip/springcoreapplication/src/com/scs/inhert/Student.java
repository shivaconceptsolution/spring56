package com.scs.inhert;

public class Student {
   private int rno;
   private String sname;
   Student(int rno,String sname)
   {
	   super();
	   this.rno=rno;
	   this.sname=sname;
   }
   public void display()
   {
	   System.out.println("rno is "+rno);
	   System.out.println("name is "+sname);
	   
   }
}
