package com.scs.inhert;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AccessCourseStudentData {

	public static void main(String[] args) {
		ApplicationContext obj = new ClassPathXmlApplicationContext("course_student.xml");
		Course c=(Course)obj.getBean("e2");
		c.display();

	}

}
