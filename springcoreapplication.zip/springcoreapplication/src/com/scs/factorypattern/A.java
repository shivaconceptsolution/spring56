package com.scs.factorypattern;

public class A {
	  
	    private A()
	    {
	        System.out.println("private constructor");
	    }
	    public A getA() //non static factory method
	    {
	    	   
	           System.out.println("factory method ");
	           A obj=new A();
	           return obj;
	    }

	    public void msg()
	    {
	           System.out.println("hello user");
	    }

}
