package com.scs.factorypattern;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class FactoryMain {

	public static void main(String[] args) {
		 ApplicationContext context=new ClassPathXmlApplicationContext("factoryContext.xml");  
		 A obj=(A)context.getBean("a");  
		 obj.msg();  

	}

}
