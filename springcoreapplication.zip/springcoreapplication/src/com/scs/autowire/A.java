package com.scs.autowire;

public class A {
	B b;  
	A(B b){
		this.b=b;
		System.out.println("a constructor is created");
		}  
	
	
	void display(){  
	    System.out.println("A Method Display"); 
	    b.print();  
		}  
}
