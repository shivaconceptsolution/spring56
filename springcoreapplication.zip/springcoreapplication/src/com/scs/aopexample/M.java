package com.scs.aopexample;

public class M {
	public void m(){System.out.println("actual business logic");}  
}
