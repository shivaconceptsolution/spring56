package com.scs.aopexample;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MMain {

	public static void main(String[] args) {
		ApplicationContext obj = new ClassPathXmlApplicationContext("aopContext.xml");
		M objm= (M)obj.getBean("proxy",M.class);
		objm.m();

	}

}
